package com.cucumber.parallel_demo.runner;
import org.junit.platform.suite.api.ConfigurationParameter;
import org.junit.platform.suite.api.IncludeEngines;
import org.junit.platform.suite.api.SelectClasspathResource;
import org.junit.platform.suite.api.Suite;
import static io.cucumber.junit.platform.engine.Constants.GLUE_PROPERTY_NAME;

@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("src/test/java/com/cucumber/parallel_demo/definitions")
@ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "com.cucumber.parallel_demo.definitions")
public class RunCucumberTest {

}