package com.cucumber.parallel_demo.definitions;

import io.cucumber.java.en.Given;

public class StepDefs {

    @Given("Step from {string} in {string} feature file")
    public void step(String scenario, String file) throws InterruptedException {
    	Thread.sleep(2000);
        System.out.format("Thread ID - %2d - %s from %s feature file.\n",
        Thread.currentThread().getId(), scenario,file);
        System.out.println("wait");
    }
}