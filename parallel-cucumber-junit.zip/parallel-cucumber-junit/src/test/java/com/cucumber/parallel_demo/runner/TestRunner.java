package com.cucumber.parallel_demo.runner;



import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/test/resources/feature"}, glue= {"com.cucumber.parallel_demo.definitions"})
public class TestRunner {

}
